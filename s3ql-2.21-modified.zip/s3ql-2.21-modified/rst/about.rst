.. -*- mode: rst -*-

.. include:: ../README.rst
   :end-before: Typical Usage

Contributing
============

The S3QL source code is available both on GitHub_ and BitBucket_.

.. _BitBucket: https://bitbucket.org/nikratio/s3ql/
.. _GitHub: https://github.com/s3ql/main
