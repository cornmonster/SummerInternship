.. -*- mode: rst -*-

.. only:: man

   S3QL is a file system for online data storage. Before using S3QL, make
   sure to consult the full documentation (rather than just the man pages
   which only briefly document the available userspace commands).
