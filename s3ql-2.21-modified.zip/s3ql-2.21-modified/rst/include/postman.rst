.. -*- mode: rst -*-

See Also
========

The S3QL homepage is at https://bitbucket.org/nikratio/s3ql/.

The full S3QL documentation should also be installed somewhere on your
system, common locations are :file:`/usr/share/doc/s3ql` or
:file:`/usr/local/doc/s3ql`.
