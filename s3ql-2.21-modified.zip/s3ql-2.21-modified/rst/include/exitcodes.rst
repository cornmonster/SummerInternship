.. -*- mode: rst -*-

:0:
   Everything went well.

:1:
   An unexpected error occured. This may indicate a bug in the
   program.

:2:
   Invalid command line argument.
